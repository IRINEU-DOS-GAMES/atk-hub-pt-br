@echo off
title ATK HUB - Portugues (Brasil)
echo Instalador local de idioma. Feche o ATK HUB antes de continuar.
"C:\Windows\py.exe" -3 "%~dp0aplicar.py" --apply
echo.
pause
