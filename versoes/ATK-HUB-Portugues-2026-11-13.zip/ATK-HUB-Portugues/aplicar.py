"""Instalador offline de pt-BR para o ATK HUB. Nao altera perfis ou firmware."""
import argparse
import copy
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
TARGET = Path(r'C:\Program Files\ATK HUB\resources\main\app.asar')
CONFIG = json.loads((HERE / 'compatibilidade.json').read_text(encoding='utf-8'))
ORIGINAL_HASH = CONFIG['archive_sha256']
BACKUP = TARGET.with_name('app.asar.original-' + ORIGINAL_HASH[:12] + '.bak')
MARKER = '/* ATK-HUB-pt-BR-local-v1 */'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def files(directory, prefix=''):
    for name, info in directory.get('files', {}).items():
        path = prefix + name
        if 'files' in info:
            yield from files(info, path + '/')
        else:
            yield path, info

def read_asar(data):
    if len(data) < 16:
        raise ValueError('Arquivo ASAR incompleto.')
    first, header_size, payload_size, string_size = struct.unpack('<4I', data[:16])
    if first != 4 or header_size != payload_size + 4 or string_size > header_size:
        raise ValueError('Cabecalho ASAR desconhecido.')
    header = json.loads(data[16:16 + string_size])
    base = 8 + header_size
    return header, base

def patched_script(source):
    if MARKER in source:
        raise ValueError('O portugues ja esta instalado.')
    replacements = [
        (CONFIG['locale_map'] + '={', CONFIG['locale_map'] + '={pt:"pt-BR","pt-BR":"pt-BR","pt-PT":"pt-BR",'),
        ('{label:"English",value:"en-us"}', '{label:"English",value:"en-us"},{label:"Português (Brasil)",value:"pt-BR"}'),
    ]
    dictionary = json.loads((HERE / 'pt-BR.json').read_text(encoding='utf-8'))
    original = '"../../packages/atk-i18n/locales/pt-BR.json":' + CONFIG['pt_module']
    payload = '{default:' + json.dumps(dictionary, ensure_ascii=True, separators=(',', ':')) + '}'
    if CONFIG.get('locale_loading') == 'async':
        payload = '()=>Promise.resolve(' + payload + ')'
    replacement = '"../../packages/atk-i18n/locales/pt-BR.json":' + payload
    replacements.append((original, replacement))
    for old, new in replacements:
        if source.count(old) != 1:
            raise ValueError('Esta versao do ATK HUB e diferente da versao validada. Nada foi instalado.')
        source = source.replace(old, new, 1)
    return MARKER + '\n' + source

def build(original):
    if sha(original) != ORIGINAL_HASH:
        raise ValueError('O ATK HUB foi atualizado novamente. Este instalador nao corresponde a versao atual.')
    header, base = read_asar(original)
    header = copy.deepcopy(header)
    payload = bytearray()
    renderer = CONFIG['renderer_path']
    replaced = 0
    for path, info in files(header):
        if 'offset' not in info or info.get('unpacked'):
            continue
        start = base + int(info['offset'])
        content = original[start:start + info['size']]
        if len(content) != info['size']:
            raise ValueError('Arquivo ASAR truncado: ' + path)
        if path == renderer:
            content = patched_script(content.decode('utf-8')).encode('utf-8')
            replaced += 1
            if 'integrity' in info:
                integrity = info['integrity']
                if integrity.get('algorithm') != 'SHA256':
                    raise ValueError('Algoritmo de integridade desconhecido.')
                block_size = integrity.get('blockSize', 4194304)
                integrity['hash'] = sha(content)
                integrity['blocks'] = [sha(content[i:i + block_size]) for i in range(0, len(content), block_size)]
        info['offset'] = str(len(payload))
        info['size'] = len(content)
        payload.extend(content)
    if replaced != 1:
        raise ValueError('Nao foi encontrado o modulo de idioma esperado.')
    raw_header = json.dumps(header, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    padded = raw_header + b'\x00' * ((-len(raw_header)) % 4)
    header_payload = struct.pack('<I', len(raw_header)) + padded
    header_pickle = struct.pack('<I', len(header_payload)) + header_payload
    result = struct.pack('<II', 4, len(header_pickle)) + header_pickle + payload
    # Every original resource except the language module must remain identical.
    new_header, new_base = read_asar(result)
    old_files = dict(files(read_asar(original)[0]))
    for path, info in files(new_header):
        if 'offset' not in info or info.get('unpacked'):
            continue
        content = result[new_base + int(info['offset']):new_base + int(info['offset']) + info['size']]
        if path != renderer:
            previous = old_files[path]
            old_content = original[base + int(previous['offset']):base + int(previous['offset']) + previous['size']]
            if content != old_content:
                raise ValueError('Recurso inesperadamente alterado: ' + path)
    return bytes(result)

def require_closed_and_admin():
    if os.name != 'nt':
        raise ValueError('Este instalador deve ser executado no Windows.')
    if not ctypes.windll.shell32.IsUserAnAdmin():
        raise ValueError('Clique com o botao direito em Instalar-portugues.cmd e escolha Executar como administrador.')
    processes = subprocess.run(['tasklist', '/FI', 'IMAGENAME eq ATK HUB.exe', '/FO', 'CSV', '/NH'], capture_output=True, creationflags=0x08000000, check=True)
    if b'ATK HUB.exe' in processes.stdout:
        raise ValueError('Feche o ATK HUB completamente, inclusive na bandeja perto do relogio, e tente novamente.')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--restore', action='store_true')
    parser.add_argument('--preview', type=Path)
    args = parser.parse_args()
    if args.preview:
        result = build(TARGET.read_bytes())
        args.preview.write_bytes(result)
        print('Arquivo de teste criado. A instalacao original nao foi alterada.')
        return
    if args.apply == args.restore:
        raise ValueError('Escolha --apply ou --restore.')
    require_closed_and_admin()
    if args.restore:
        if not BACKUP.exists() or sha(BACKUP.read_bytes()) != ORIGINAL_HASH:
            raise ValueError('Backup original valido nao encontrado.')
        current = TARGET.read_bytes()
        if sha(current) != sha(build(BACKUP.read_bytes())):
            raise ValueError('A instalacao mudou depois do patch; o backup nao sera restaurado sobre outra versao.')
        result = BACKUP.read_bytes()
    else:
        original = TARGET.read_bytes()
        result = build(original)
        if BACKUP.exists():
            if sha(BACKUP.read_bytes()) != ORIGINAL_HASH:
                raise ValueError('Ja existe um backup diferente. Nada foi alterado.')
        else:
            shutil.copy2(TARGET, BACKUP)
        if sha(TARGET.read_bytes()) != ORIGINAL_HASH:
            raise ValueError('O arquivo mudou durante a preparacao. Feche o atualizador e tente novamente.')
    temporary = TARGET.with_name('app.asar.pt-br.new')
    with temporary.open('xb') as file:
        file.write(result)
        file.flush()
        os.fsync(file.fileno())
    if sha(temporary.read_bytes()) != sha(result):
        raise ValueError('Falha ao validar o arquivo preparado. A instalacao original nao foi alterada.')
    os.replace(temporary, TARGET)
    if sha(TARGET.read_bytes()) != sha(result):
        raise ValueError('Falha na verificacao final. O backup original foi preservado.')
    print('Original restaurado.' if args.restore else 'Pronto! Abra o ATK HUB e escolha Portugues (Brasil) em Settings > Language.')
    print('Backup original: ' + str(BACKUP))

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('ERRO: ' + str(error))
        sys.exit(1)
