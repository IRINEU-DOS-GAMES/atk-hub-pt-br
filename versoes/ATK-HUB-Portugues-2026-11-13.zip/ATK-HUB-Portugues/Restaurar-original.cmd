@echo off
title ATK HUB - Restaurar idioma original
"C:\Windows\py.exe" -3 "%~dp0aplicar.py" --restore
echo.
pause
